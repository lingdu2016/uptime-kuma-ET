# How to run

Node.js (ts-node)

```bash
ts-node index.ts
```

Deno

```bash
deno run --allow-net index.ts
```

Bun.js

```bash
bun index.ts
```
